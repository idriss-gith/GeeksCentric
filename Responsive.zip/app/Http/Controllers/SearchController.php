<?php

namespace App\Http\Controllers;


use App\Models\ChatRoom;
use Illuminate\Http\Request;


class SearchController extends Controller
{
    public function search(Request $request, $topic){
        return ChatRoom::where('name','LIKE','%'.$topic.'%')
        ->orderBy('Created_at','DESC')
        ->get();
    }
}

