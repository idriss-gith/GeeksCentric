<template>
           <img :src="'/images/logo.jpg'" alt="">

</template>
