<template>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <div class="min-h-screen sm:grid sm:grid-cols-2 flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-indigo-500">
        <div class="">
            <img :src="'/images/chat.jpeg'" alt="">
        </div>

        <div class="w-full sm:max-w-md  mt-6 px-6 py-4 bg-black shadow-md overflow-hidden sm:rounded-lg">
            <slot />
                <div class="text-center text-red-500 mt-3">
                     <p>Follow us on social media </p>

                    <div class="mt-3">
                        <a href="" class="text-white font-bold m-1 p-1 rounded-xl bg-red-500"><i class="fab fa-facebook"></i></a>
                        <a href="" class="text-white font-bold m-1 p-1 rounded-xl bg-red-500"><i class="fab fa-instagram"></i></a>
                        <a href="" class="text-white font-bold m-1 p-1 rounded-xl bg-red-500"><i class="fab fa-twitter"></i></a>
                    </div>

                </div>
        </div>
    </div>
</template>


<style scoped>
    .bg-indigo-500{
      background-color:#000 !important; 

    }
</style>


