<template>
    <Head title="Log in" />

    <jet-authentication-card>
        <template #logo>
            <jet-authentication-card-logo />
        </template>

        <jet-validation-errors class="mb-4" />

        <div v-if="status" class="mb-4 font-medium text-sm text-green-600">
            {{ status }}
        </div>
        

        <form @submit.prevent="submit">
            <div class="mb-3">
                <h1  class="text-yellow-700 font-bold text-lg "> Login </h1>
                <hr style="width:50px; height:1vh; background: green">
        
            </div>
            <div>
                <jet-label for="email" value="Email" class="text-yellow-700 font-bold text-lg" />
                <jet-input id="email" type="email" class="mt-1 block w-full rounded-lg" v-model="form.email" required autofocus />
            </div>

            <div class="mt-4">
                <jet-label for="password" value="Password" class="text-yellow-700 font-bold text-lg" />
                <jet-input id="password" type="password" class="mt-1 block w-full rounded-lg" v-model="form.password" required autocomplete="current-password" />
            </div>

            <div class="block mt-4">
                <label class="flex items-center">
                    <jet-checkbox name="remember" v-model:checked="form.remember" />
                    <span class="ml-2 text-sm text-white">Remember me</span>
                </label>
            </div>

            <div class="flex items-center justify mt-4 mb-2">
                <Link v-if="canResetPassword" :href="route('password.request')" class="underline text-sm text-white hover:text-gray-900">
                    Forgot your password?
                </Link>

            
            </div>


               <div>
                    <button class="p-1 rounded-lg block w-full text-center bg-yellow-700 text-black font-bold">Sign In</button>
                    <p class="text-white mt-2">Don't have an account ?  <a href="/register" class="font-bold text-yellow-700">Sign Up</a></p>
               </div>
        </form>
    </jet-authentication-card>

</template>

<script>
    import { defineComponent } from 'vue'
    import JetAuthenticationCard from '@/Jetstream/AuthenticationCard.vue'
    import JetAuthenticationCardLogo from '@/Jetstream/AuthenticationCardLogo.vue'
    import JetButton from '@/Jetstream/Button.vue'
    import JetInput from '@/Jetstream/Input.vue'
    import JetCheckbox from '@/Jetstream/Checkbox.vue'
    import JetLabel from '@/Jetstream/Label.vue'
    import JetValidationErrors from '@/Jetstream/ValidationErrors.vue'
    import { Head, Link } from '@inertiajs/inertia-vue3';

    export default defineComponent({
        components: {
            Head,
            JetAuthenticationCard,
            JetAuthenticationCardLogo,
            JetButton,
            JetInput,
            JetCheckbox,
            JetLabel,
            JetValidationErrors,
            Link,
        },

        props: {
            canResetPassword: Boolean,
            status: String
        },

        data() {
            return {
                form: this.$inertia.form({
                    email: '',
                    password: '',
                    remember: false
                })
            }
        },

        methods: {
            submit() {
                this.form
                    .transform(data => ({
                        ... data,
                        remember: this.form.remember ? 'on' : ''
                    }))
                    .post(this.route('login'), {
                        onFinish: () => this.form.reset('password'),
                    })
            }
        }
    })
</script>
