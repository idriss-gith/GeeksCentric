<template>
  <div class="p-2 shadow mb-3 rounded-lg shadow-sm hover:shadow-lg" >
   
   <p class="font-bold">{{ message.user.name}} </p> 
    <hr>
  
    <div class="mt-2">
        {{message.message}}
    </div>
  
  </div>
</template>

<script>
export default {
props:['message'],
methods:{

  
}
}
</script>

<style>

</style>