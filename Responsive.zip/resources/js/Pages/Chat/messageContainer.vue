<template>
<div class="h-full w-full">
    <div class="p-2 flex flex-col-reverse overflow-scroll" style="height:60vh">

        <div v-for="(message,index) in messages" :key="index" >
            <message-item :message="message"/>

        </div>

    </div>

</div>  
</template>

<script>
import messageItem from './messageItem.vue'
export default {
    components:{ messageItem},
    props:['messages']

}
</script>

<style>

</style>