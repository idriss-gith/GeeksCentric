<template >
    <Head title="International Real-Time Chat App" />
    

    <div class="relative sm:flex  items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center sm:pt-0 ">
        <div class="top-0 sticky bg-gray-100 p-2">
            <div v-if="canLogin" class="left-0  fixed top-0  px-6 py-4 sm:block">
                <img :src="'/images/logo.jpg'" width="50" class="absolute top-0" height="20" alt="" >
            </div>
            <div v-if="canLogin" class="right-0 fixed top-0 px-6 py-4 sm:block">
                <Link v-if="$page.props.user" :href="route('dashboard')" class="text-sm text-white underline">
                    Dashboard
                </Link>

                <template v-else>
                    <Link :href="route('login')" class="text-sm text-white underline">
                        Log in
                    </Link>

                    <Link v-if="canRegister" :href="route('register')" class="ml-4 text-sm text-white underline">
                        Register
                    </Link>
                </template>
            </div>

        </div>
        
         <!-- This example requires Tailwind CSS v2.0+ -->



        <div class="p-6  max-w-6xl mx-auto sm:px-6 lg:px-8" style="">
            

            <div class="mt-4  dark:bg-gray-800 overflow-hidden  sm:rounded-lg">
             
                
                   
                    <form class="bg-white ">
                        <div class="w-96" style=" ">
                            <input @keyup.enter="check()"  @keyup="submit()" v-model="topic" type="text"  class="block w-full" placeholder="Type your favorite topic">
                         
                         
                        </div>
                        <div class=" w-96 " style="height:500px; overflow:scroll" v-if="topic">
                            <div  v-for="(item,index) in result" :key="index">
                            <div class="p-1">
                                <!-- <p class="text-black block border-b-1 border-black" @click="ref(item.name)"> {{ item.name }}</p> -->
                                <p class="text-black block border-b-1 border-black" @click="ref()"> {{ item.name }}</p>
               
                            </div>
                            </div>
                        </div>

                    </form>
                  
            </div>
        </div>
    </div>


</template>

<style scoped>
    .bg-gray-100 {
      background-color:#330623 !important; 
  /*  background-color: #f7fafc;*/
        background-color: rgba(247, 250, 252, var(--tw-bg-opacity));
    }

    .border-gray-200 {
        border-color: #edf2f7;
        border-color: rgba(237, 242, 247, var(--tw-border-opacity));
    }

    .text-gray-400 {
        color: #cbd5e0;
        color: rgba(203, 213, 224, var(--tw-text-opacity));
    }

    .text-gray-500 {
        color: #a0aec0;
        color: rgba(160, 174, 192, var(--tw-text-opacity));
    }

    .text-gray-600 {
        color: #718096;
        color: rgba(113, 128, 150, var(--tw-text-opacity));
    }

    .text-gray-700 {
        color: #4a5568;
        color: rgba(74, 85, 104, var(--tw-text-opacity));
    }

    .text-gray-900 {
        color: #1a202c;
        color: rgba(26, 32, 44, var(--tw-text-opacity));
    }

    @media (prefers-color-scheme: dark) {
        .dark\:bg-gray-800 {
            background-color: #2d3748;
            background-color: rgba(45, 55, 72, var(--tw-bg-opacity));
        }

        .dark\:bg-gray-900 {
            background-color: #1a202c;
            background-color: rgba(26, 32, 44, var(--tw-bg-opacity));
        }

        .dark\:border-gray-700 {
            border-color: #4a5568;
            border-color: rgba(74, 85, 104, var(--tw-border-opacity));
        }

        .dark\:text-white {
            color: #fff;
            color: rgba(255, 255, 255, var(--tw-text-opacity));
        }

        .dark\:text-gray-400 {
            color: #cbd5e0;
            color: rgba(203, 213, 224, var(--tw-text-opacity));
        }
    }
</style>

<script>
    import { defineComponent } from 'vue'
    import { Head, Link } from '@inertiajs/inertia-vue3';
import axios from 'axios';

    export default defineComponent({
        components: {
            Head,
            Link,
        },

        props: {
            canLogin: Boolean,
            canRegister: Boolean,
            laravelVersion: String,
            phpVersion: String,
        },
      data: function(){
          return {
              topic : '',
              result:[]
              
              }
      },
        methods :{

            submit(){
            
            if(this.topic ==''){
                return;
            }
                axios.get('/search/' + this.topic)
                .then(response =>{
                    this.result=response.data;
                    console.log(response.data);
                })
                .catch(err =>{
                    this.topic=err;
                    //console.log(err)

                })
             
                // console.log(this.topic)
            },
        check(){
                return;
             
        },
        ref(){
          window.location="/chat";
        }

        }
    })
</script>
